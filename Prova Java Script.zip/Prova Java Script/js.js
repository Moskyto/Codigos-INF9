
    const btn = document.querySelector("btn");


        function calcidade(){

        if (idade < 18) {
            res.innerHTML = `<br>Seu nome é ${nome}<br>Você nasceu no ano de ${ano} e tem ${idade} de idade <br>Você é da cidade de ${cidade} no estado ${estado}<br>  Você é menor de idade!<br><br>Obrigado por participar! `
        } else if (idade >= 18) {
            res.innerHTML = `<br>Seu nome é ${nome}<br>Você nasceu no ano de ${ano} e tem ${idade} de idade <br>Você é da cidade de ${cidade} no estado ${estado}<br>  Você é maior de idade!<br><br>Obrigado por participar! `
        } 
        }
       





       
    
