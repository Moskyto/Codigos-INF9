<?php

    $dbhost = 'Localhost';
    $dbUsername = 'root';
    $dbPassword = '';
    $dbName = 'leonardo';

    $conexao = new mysqli($dbhost,$dbUsername,$dbPassword,$dbName);

    //if($conexao->connect_errno)
    //{
    //    echo "Erro";
    //}
    //else{
    //    echo"Conexao efetuada com sucesso";
    //}

?>