<?php
$servidor = "localhost";
$usuario = "root";
$senha = "";
$dbname = "leonardo";

//Criar a conexao 

$mysqli = new mysqli($servidor, $usuario, $senha, $dbname);

if ($mysqli->connect_error) {
    die("Erro de conexão: " . $mysqli->connect_error);
}
