const navEl = document.querySelector('.nav');
const hamburguerEl = document.querySelector('.hamburguer');

hamburguerEl.addEventListener("click", () => {
    navEl.classList.toggle("nav--open");
    hamburguerEl.classList.toggle("hamburguer--open");
})

navEl.addEventListener('click', () =>{
    navEl.classList.remove("nav--open");
    hamburguerEl.classList.remove("hamburguer--open");
})

