<?php

include 'Conexao2.php';




?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Inter:ital,opsz,wght@0,14..32,100..900;1,14..32,100..900&family=Roboto:ital,wght@0,100..900;1,100..900&display=swap"
        rel="stylesheet">
    
    <link rel="stylesheet" href="style.css?v=1.2">
    <script src="script.js" defer></script>

    <title>Menu</title>
    
</head>

<body>

    <header class="header">
        <div class="header__content">
            <a href="#" class="logo">Izijob</a>

            <nav class="nav">
                <ul class="nav__list">
                    <li class="nav__item">
                        <a href="#" class="nav__link">Pagina Inicial</a>
                    </li>
                    <li class="nav__item">
                        <a href="#" class="nav__link">Currículo</a>
                    </li>
                    <li class="nav__item">
                        <a href="#" class="nav__link">Buscas vagas</a>
                    </li>
                </ul>
            </nav>
            
            <div class="hamburguer">
                    <div class="bar"></div>
                <div class="bar"></div>
                <div class="bar"></div>
            </div>
        </div>
            
    </header>

    <h1>Busca de vagas</h1>
    <form action="">
    <div class="top-content">
    <h1>Buscar Vagas</h1>

    <div class="search-container">
      <input name="busca" placeholder="Digite a vaga ou palavra-chave" type="text">
      <button type="submit">Pesquisar</button>
    </div>
  </div>
    </form>
    <br>
    <table id="tabelaResultados" class="tabela" width="300px" height="150px" border="5" style="display: none;">
        <tr>
            <th>Empresa</th>
            <th>Cargo</th>
            <th>Remuneração</th>
        </tr>
        <?php
            if(!isset($_GET['busca'])) {
        ?>
                <tr>
                <td colspan="3">Digite algo para pesquisar</td>
                </tr>    
        <?php
        } else{      
            $pesquisa = $mysqli->real_escape_string($_GET['busca']);
            $sql_code = "SELECT * 
                FROM leo_cadastro 
                WHERE nome LIKE '%$pesquisa%' 
                OR email LIKE '%$pesquisa%' 
                OR numero LIKE '%$pesquisa%'";

            $sql_query = $mysqli->query($sql_code) or die("ERRO ao consultar!" . $mysqli->error);

        
            if($sql_query->num_rows == 0){
                ?>
                <tr>
                <td colspan="3">Nenhum resultado encontrado...</td>
                </tr>    
            <?php
            } else{
                while($dados = $sql_query->fetch_assoc()){
                    ?>
                    <tr>
                        <td><?php echo $dados['nome'];?></td>
                        <td><?php echo $dados['email'];?></td>
                        <td><?php echo $dados['numero'];?></td>
                    </tr>
                    <?php
                }
            }
            ?>
        
        
        
        <?php
        }?>
    </table>

    <script>
  window.addEventListener('DOMContentLoaded', () => {
    const urlParams = new URLSearchParams(window.location.search);
    const busca = urlParams.get('busca');

    if (busca) {
      const tabela = document.getElementById('tabelaResultados');
      if (tabela) {
        // Mostra a tabela primeiro (sem animação ainda)
        tabela.style.display = 'table';

        // Pequeno delay para permitir a transição funcionar
        setTimeout(() => {
          tabela.classList.add('mostrar-tabela');
        }, 10);
      }
    }
  });
</script>

</body>

</html>